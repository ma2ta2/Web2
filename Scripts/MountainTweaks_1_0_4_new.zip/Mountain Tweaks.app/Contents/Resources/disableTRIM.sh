#!/bin/sh

#  disableTRIM.sh
#  iTweaks
#
#  Created by Fredrik W on 17.12.11.
#  Copyright (c) 2011 Fredrik Wiker. All rights reserved.

sudo perl -pi -e 's|(\x52\x6F\x74\x61\x74\x69\x6F\x6E\x61\x6C\x00).{9}(\x00\x51)|$1\x41\x50\x50\x4C\x45\x20\x53\x53\x44$2|sg' /System/Library/Extensions/IOAHCIFamily.kext/Contents/PlugIns/IOAHCIBlockStorage.kext/Contents/MacOS/IOAHCIBlockStorage

exit