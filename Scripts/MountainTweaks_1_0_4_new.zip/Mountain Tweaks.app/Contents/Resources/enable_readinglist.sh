#!/bin/bash
defaults write com.apple.Safari ProxiesInBookmarksBar '("Top Sites","Reading List")'
exit