#!/bin/sh

#  enableTRIM.sh
#  iTweaks
#
#  Created by Fredrik W on 17.12.11.
#  Copyright (c) 2011 Fredrik Wiker. All rights reserved.

sudo perl -pi -e 's|(\x52\x6F\x74\x61\x74\x69\x6F\x6E\x61\x6C\x00{1,20})[^\x00]{9}(\x00{1,20}\x51)|$1\x00\x00\x00\x00\x00\x00\x00\x00\x00$2|sg' /System/Library/Extensions/IOAHCIFamily.kext/Contents/PlugIns/IOAHCIBlockStorage.kext/Contents/MacOS/IOAHCIBlockStorage

exit