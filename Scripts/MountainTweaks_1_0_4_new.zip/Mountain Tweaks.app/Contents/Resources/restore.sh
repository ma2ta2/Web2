defaults write com.apple.dock no-glass -boolean NO
chflags hidden ~/Library
defaults write NSGlobalDomain NSAutomaticWindowAnimationsEnabled -bool true
defaults write com.apple.Mail DisableReplyAnimations -bool NO
'Applications/Mountain Tweaks.app/Contents/Resources/enable_readinglist.sh'
defaults write NSGlobalDomain NSAutomaticSpellingCorrectionEnabled -bool YES
defaults write -g ApplePressAndHoldEnabled -bool true
defaults write -g AppleShowScrollBars -string Never
defaults write com.Apple.Finder AppleShowAllFiles false
defaults write com.apple.CrashReporter DialogType prompt
defaults write com.apple.dock use-new-list-stack -boolean no
defaults write com.apple.dock mouse-over-hilite-stack -boolean no
sudo launchctl unload -w /System/Library/LaunchDaemons/ftp.plist
sudo mv /System/Library/CoreServices/Dock.app/Contents/Resources/ecsb_background_tile_backup.png /System/Library/CoreServices/Dock.app/Contents/Resources/ecsb_background_tile.png
sudo tmutil enablelocal
defaults write com.apple.NetworkBrowser BrowseAllInterfaces 0
defaults write com.apple.dock itunes-notifications -bool FALSE
sudo rm -rf '/Library/Application Support/SIMBL/Plugins/ColorfulSidebar.bundle' 'Applications/Lion Tweaks.app/Contents/Resources/disableTRIM.sh'
sudo kextcache -system-prelinked-kernel
sudo kextcache -system-caches
defaults write com.apple.iCal IncludeDebugMenu 0
sudo chmod 755 /System/Library/CoreServices/Search.bundle/Contents/MacOS/Search
defaults write -g CGContextHighlight2xScaledImages NO
defaults write -g ApplePersistence -bool yes
defaults write com.apple.finder QLEnableTextSelection -bool false
sudo mv '/Applications/Mountain Tweaks.app/Contents/Resources/linen.tiff' '/System/Library/CoreServices/NotificationCenter.app/Contents/Resources/linen.tiff'
defaults write com.apple.DiskUtility DUDebugMenuEnabled 0
defaults write -g NSDisableAutomaticTermination -bool FALSE
defaults write -g NSScrollAnimationEnabled -bool YES
defaults write -g NSScrollViewRubberbanding -int 1
defaults write com.apple.finder ProhibitGoToFolder -bool false
defaults delete com.apple.finder IKImageFlowShowFrameRate
open 'Applications/Mountain Tweaks.app/Contents/Resources/ical_backup.pkg'
open 'Applications/Mountain Tweaks.app/Contents/Resources/adressbook_backup.pkg'
open 'Applications/Mountain Tweaks.app/Contents/Resources/contacts_ml_backup.pkg'
open 'Applications/Mountain Tweaks.app/Contents/Resources/calendar_ml_backup.pkg'